##一个基础的权限管理系统
#####jty是由spring+springmvc+hibernate+shiro+quartz+maven+easyui写的一个框架集合，参考了springside,jeesite等一些优秀的开源项目，目前实现了一个基础的权限管理系统，界面美观(我觉的挺好看...囧)，后面如果有空闲时间会继续添加一些常见的功能，工作流、webservice什么的，有空也会修改。
#####后台访问路径：http://localhost:8080/jty/a
#####帐号：admin 	密码：123456
#####系统截图
![](http://tianyuyun.qiniudn.com/jty1.png)
![](http://tianyuyun.qiniudn.com/jty2.png)
![](http://tianyuyun.qiniudn.com/jty3.png)
![](http://tianyuyun.qiniudn.com/jty4.png)
![](http://tianyuyun.qiniudn.com/jty5.png)