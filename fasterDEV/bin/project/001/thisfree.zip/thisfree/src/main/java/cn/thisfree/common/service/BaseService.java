package cn.thisfree.common.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import cn.thisfree.common.dao.BaseDao;
import cn.thisfree.common.dao.Page;
import cn.thisfree.common.dao.PropertyFilter;


/**
 * 基础service 所有service继承该类
 * 提供基础的实体操作方法
 * 使用HibernateDao<T,PK>进行业务对象的CRUD操作,子类需重载getEntityDao()函数提供该DAO.
 * @author ty
 * @date 2014年8月20日 上午11:21:14
 * @param <T>
 * @param <PK>
 */
public interface BaseService<T,PK extends Serializable > {
	
	/**
	 * 子类需要实现该方法，提供注入的dao
	 * @return
	 */
	public abstract BaseDao<T, PK> getDao();
	
	public T findById(final PK id);

	public void save(final T entity);
	
	public void update(final T entity);
	
	public void delete(final T entity);
	
	public void delete(final PK id);
	
	public List<T> getAll();
	
	public List<T> getAll(Boolean isCache);

	public List<T> search(final List<PropertyFilter> filters);
	
	public Page<T> search(final Page<T> page, final List<PropertyFilter> filters);
	
	public Page<T> search(final Page<T> page, final String hql,final Map<String, ?> values);
	
	public Page<T> search(final Page<T> page, final String hql,final Object... values);
	
}
