package cn.thisfree.common.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import cn.thisfree.common.dao.BaseDao;
import cn.thisfree.common.dao.Page;
import cn.thisfree.common.dao.PropertyFilter;


/**
 * 基础service 所有service继承该类
 * 提供基础的实体操作方法
 * 使用HibernateDao<T,PK>进行业务对象的CRUD操作,子类需重载getEntityDao()函数提供该DAO.
 * @author ty
 * @date 2014年8月20日 上午11:21:14
 * @param <T>
 * @param <PK>
 */
public abstract class BaseServiceImpl<T,PK extends Serializable > implements BaseService<T, PK>{
	
	/**
	 * 子类需要实现该方法，提供注入的dao
	 * @return
	 */
	public abstract BaseDao<T, PK> getDao();
	
	public T findById(final PK id) {
		return getDao().find(id);
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public void save(final T entity) {
		getDao().save(entity);
	}
	
	@Transactional(propagation=Propagation.REQUIRED)
	public void update(final T entity){
		getDao().save(entity);
	}
	
	@Transactional(propagation=Propagation.REQUIRED)
	public void delete(final T entity){
		getDao().delete(entity);
	}
	
	@Transactional(propagation=Propagation.REQUIRED)
	public void delete(final PK id){
		getDao().deleteById(id);
	}
	
	public List<T> getAll(){
		return getDao().findAll();
	}
	
	public List<T> getAll(Boolean isCache){
		return getDao().findAll(isCache);
	}
	
	
	public List<T> search(final List<PropertyFilter> filters){
		return getDao().find(filters);
	}
	
	
	public Page<T> search(final Page<T> page, final List<PropertyFilter> filters) {
		return getDao().findPage(page, filters);
	}
	
	
	public Page<T> search(final Page<T> page, final String hql,final Map<String, ?> values) {
		return getDao().findPage(page, hql, values);
	}
	
	public Page<T> search(final Page<T> page, final String hql,final Object... values) {
		return getDao().findPage(page, hql, values);
	}
	
}
