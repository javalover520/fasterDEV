/**
 * There are <a href="https://github.com/thinkgem/jeesite">JeeSite</a> code generation
 */
package cn.thisfree.module.action;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.thisfree.common.dao.Page;
import cn.thisfree.common.dao.PropertyFilter;
import cn.thisfree.common.web.BaseController;

import cn.thisfree.module.service.*;
import cn.thisfree.module.entity.*;

 /**
 * 
 * DefaultController
 * @author huangxiaolong@aliyun.com
 * @version 1.0.0.0
 */
@Controller
@RequestMapping("/module/test")
public class DefaultController extends BaseController {
	private static Logger logger=LoggerFactory.getLogger(BaseController.class);
	private static final long serialVersionUID = 1L;
	
	@Autowired
	private DefaultService defaultService;
	
	/**
	 * 报表数据首页
	 */
	@RequestMapping(value = {"index", ""},method= RequestMethod.GET)
	public String index() {
		return "test/test_list.jsp";
	}
	
	/**
	 * 报表视图数据
	 */
	@RequiresPermissions("test:view")
	@RequestMapping(value={"list"},method = RequestMethod.GET)
	@ResponseBody
	public Map<String, Object> list(HttpServletRequest request) {
		List<PropertyFilter> filters = PropertyFilter.buildFromHttpRequest(request);
		List<DefaultEntity> list=defaultService.getReportList(filters);
		
		Map<String,Object> data=new HashMap<String,Object>();
		return data;
	}

}
