/**
 * There are <a href="https://github.com/thinkgem/jeesite">JeeSite</a> code generation
 */
package cn.thisfree.module.dao;

import cn.thisfree.common.dao.BaseDaoImpl;
import org.springframework.stereotype.Component;
import cn.thisfree.common.dao.PropertyFilter;
import cn.thisfree.module.entity.*;

/**
 * DAO自定义接口
 * DefaultDaoImpl
 * @author huangxiaolong@aliyun.com
 * @version 1.0.0.0
 */
@Component
public class DefaultDao extends BaseDaoImpl<DefaultEntity,Long>{

}
