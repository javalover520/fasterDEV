/**
 * There are <a href="https://github.com/thinkgem/jeesite">JeeSite</a> code generation
 */
package cn.thisfree.module.service;
import cn.thisfree.common.service.BaseService;
import cn.thisfree.common.dao.BaseDao;
import java.util.Map;
import java.util.List;
import cn.thisfree.common.dao.PropertyFilter;
import cn.thisfree.module.entity.*;
 
/**
 * 
 * DefaultService
 * @author huangxiaolong@aliyun.com
 * @version 1.0.0.0
 */

public interface DefaultService extends BaseService<DefaultEntity,Long> {
	public List<DefaultEntity> getReportList(List<PropertyFilter> filters);
}
