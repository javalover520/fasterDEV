/**
 * There are <a href="https://github.com/thinkgem/jeesite">JeeSite</a> code generation
 */
package cn.thisfree.module.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import cn.thisfree.common.dao.BaseDao;
import cn.thisfree.common.service.BaseServiceImpl;
import cn.thisfree.common.dao.PropertyFilter;
import cn.thisfree.module.service.*;
import cn.thisfree.module.dao.*;
import cn.thisfree.module.entity.*;

/**
 * 
 * DefaultService
 * @author huangxiaolong@aliyun.com
 * @version 1.0.0.0
 */
@Component
@Transactional(rollbackFor=Exception.class)
public class DefaultServiceImpl extends BaseServiceImpl<DefaultEntity,Long> implements DefaultService{
	@SuppressWarnings("unused")
	private static Logger logger = LoggerFactory.getLogger(DefaultService.class);
	
	@Autowired
	private DefaultDao defaultDao;
	
	public BaseDao<DefaultEntity,Long> getDao(){
		return defaultDao;
	}
	
	/**
	 * 获取统计报表
	 * DefaultService
	 * @author huangxiaolong@aliyun.com
	 * @version 1.0.0.0
	 */
	public List<DefaultEntity> getReportList(List<PropertyFilter> filters){
		List<DefaultEntity> result=new ArrayList<DefaultEntity>();
		List<Map> list=getDao().findBySql("select * from organization", null, Map.class);
		for(Map map:list){
			DefaultEntity entity=new DefaultEntity();
			entity.setId((Integer)map.get("id"));
			entity.setOrgName((String)map.get("org_name"));
			entity.setPid((Integer)map.get("pid"));
			entity.setOrgType((String)map.get("org_type"));
			entity.setOrgSort((Integer)map.get("org_sort"));
			entity.setOrgLevel((Integer)map.get("org_level"));
			entity.setOrgCode((String)map.get("org_code"));
			entity.setAreaId((Integer)map.get("area_id"));
			result.add(entity);
		}
		return result;
	}
	
}
