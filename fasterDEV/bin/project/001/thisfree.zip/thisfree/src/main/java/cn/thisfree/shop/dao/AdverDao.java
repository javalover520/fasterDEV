package cn.thisfree.shop.dao;

import cn.thisfree.common.dao.BaseDaoImpl;
import cn.thisfree.shop.entity.Adver;

/**
 * 广告DAO
 * @author ty
 * @date 2015年1月22日
 */
public class AdverDao  extends BaseDaoImpl<Adver, Integer>{

}
