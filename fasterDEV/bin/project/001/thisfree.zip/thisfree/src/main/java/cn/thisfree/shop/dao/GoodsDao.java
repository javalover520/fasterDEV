package cn.thisfree.shop.dao;

import org.springframework.stereotype.Repository;

import cn.thisfree.common.dao.BaseDaoImpl;
import cn.thisfree.shop.entity.Goods;

/**
 * 商品DAO
 * @author ty
 * @date 2015年1月22日
 */
@Repository
public class GoodsDao extends BaseDaoImpl<Goods, Integer>{

}
