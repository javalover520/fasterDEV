package cn.thisfree.shop.dao;

import org.springframework.stereotype.Repository;

import cn.thisfree.common.dao.BaseDaoImpl;
import cn.thisfree.shop.entity.GoodsType;

/**
 * 商品类型DAO
 * @author ty
 * @date 2015年1月22日
 */
@Repository
public class GoodsTypeDao extends BaseDaoImpl<GoodsType, Integer>{

}
