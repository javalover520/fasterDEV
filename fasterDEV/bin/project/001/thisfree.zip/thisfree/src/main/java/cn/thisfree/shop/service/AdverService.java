package cn.thisfree.shop.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.thisfree.common.dao.BaseDao;
import cn.thisfree.common.service.BaseServiceImpl;
import cn.thisfree.shop.dao.AdverDao;
import cn.thisfree.shop.entity.Adver;

/**
 * 广告service
 * @author ty
 * @date 2015年1月22日
 */
@Service
@Transactional(readOnly=true)
public class AdverService extends BaseServiceImpl<Adver, Integer>{
	
	@Autowired
	private AdverDao adverDao;

	@Override
	public BaseDao<Adver, Integer> getDao() {
		return adverDao;
	}

}
