package cn.thisfree.shop.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.thisfree.common.dao.BaseDao;
import cn.thisfree.common.service.BaseServiceImpl;
import cn.thisfree.shop.dao.GoodsTypeDao;
import cn.thisfree.shop.entity.GoodsType;

/**
 * 商品类型service
 * @author ty
 * @date 2015年1月22日
 */
@Service
@Transactional(readOnly=true)
public class GoodsTypeService extends BaseServiceImpl<GoodsType, Integer> {
	
	@Autowired
	private GoodsTypeDao goodsTypeDao;

	@Override
	public BaseDao<GoodsType, Integer> getDao() {
		return goodsTypeDao;
	}

}
