package cn.thisfree.system.dao;

import org.springframework.stereotype.Repository;

import cn.thisfree.common.dao.BaseDaoImpl;
import cn.thisfree.system.entity.AreaInfo;


/**
 * 区域DAO
 * @author kkomge
 * @date 2015年5月09日
 */
@Repository
public class AreaInfoDao extends BaseDaoImpl<AreaInfo, Integer>{

}
