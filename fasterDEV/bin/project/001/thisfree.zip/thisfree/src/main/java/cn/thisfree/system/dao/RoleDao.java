package cn.thisfree.system.dao;

import org.springframework.stereotype.Repository;

import cn.thisfree.common.dao.BaseDaoImpl;
import cn.thisfree.system.entity.Role;


/**
 * 角色DAO
 * @author ty
 * @date 2015年1月13日
 */
@Repository
public class RoleDao extends BaseDaoImpl<Role, Integer>{

}
