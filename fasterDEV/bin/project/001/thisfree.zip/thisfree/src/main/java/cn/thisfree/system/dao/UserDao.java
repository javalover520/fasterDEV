package cn.thisfree.system.dao;

import org.springframework.stereotype.Repository;

import cn.thisfree.common.dao.BaseDaoImpl;
import cn.thisfree.system.entity.User;


/**
 * 用户DAO
 * @author ty
 * @date 2015年1月13日
 */
@Repository
public class UserDao extends BaseDaoImpl<User, Integer>{

}
