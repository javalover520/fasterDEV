package cn.thisfree.system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.thisfree.common.dao.BaseDao;
import cn.thisfree.common.service.BaseServiceImpl;
import cn.thisfree.system.dao.AreaInfoDao;
import cn.thisfree.system.entity.AreaInfo;

/**
 * 区域service
 * @author kkomge
 * @date 2015年5月09日
 */
@Service
@Transactional(readOnly=true)
public class AreaInfoService extends BaseServiceImpl<AreaInfo, Integer>{
	
	@Autowired
	private AreaInfoDao areaInfoDao;
	
	@Override
	public BaseDao<AreaInfo, Integer> getDao() {
		return areaInfoDao;
	}

}
