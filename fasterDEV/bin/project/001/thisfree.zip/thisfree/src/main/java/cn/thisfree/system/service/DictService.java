package cn.thisfree.system.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.thisfree.common.dao.BaseDao;
import cn.thisfree.common.service.BaseServiceImpl;
import cn.thisfree.system.dao.DictDao;
import cn.thisfree.system.entity.Dict;

/**
 * 字典service
 * @author ty
 * @date 2015年1月13日
 */
@Service
@Transactional(readOnly=true)
public class DictService extends BaseServiceImpl<Dict, Integer> {
	
	@Autowired
	private DictDao dictDao;

	@Override
	public BaseDao<Dict, Integer> getDao() {
		return dictDao;
	}
}
